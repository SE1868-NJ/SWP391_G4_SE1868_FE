import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "../../header/Header";
import Footer from "../../footer/Footer";
import "../../../styles/ShipperAccount.css";

// Utility formatting functions
const formatData = {
    date: (dateString) => {
      if (!dateString) return "Chưa cập nhật";
      return new Date(dateString).toLocaleDateString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
    },
    currency: (amount) => {
      if (!amount || isNaN(amount)) return "0 VNĐ";
      return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
      }).format(amount);
    },
  };
  
  const ShipperAccount = () => {
    const navigate = useNavigate();
    const [shipperData, setShipperData] = useState(null);
    const [selectedSection, setSelectedSection] = useState('personal-info');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
  
    useEffect(() => {
      const fetchShipperData = async () => {
        try {
          const shipperId = localStorage.getItem('shipperId');
          
          if (!shipperId) {
            navigate('/login');
            return;
          }
  
          const response = await fetch(`http://localhost:5000/api/shippers/${shipperId}`);
          const result = await response.json();
          
          if (!response.ok || !result.success) {
            throw new Error(result.message || "Không thể tải thông tin");
          }
  
          setShipperData(result.data);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }
      };
  
      fetchShipperData();
    }, [navigate]);

  // Render sections content
  const renderPersonalInfo = () => (
    <div className="section-content">
      <h2>Thông tin cá nhân</h2>
      <div className="info-grid">
        <div className="info-item">
          <span className="label">Họ và tên:</span>
          <span className="value">{shipperData.FullName || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Ngày sinh:</span>
          <span className="value">{formatData.date(shipperData.DateOfBirth)}</span>
        </div>
        <div className="info-item">
          <span className="label">Giới tính:</span>
          <span className="value">{shipperData.Gender || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Số điện thoại:</span>
          <span className="value">{shipperData.PhoneNumber || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Email:</span>
          <span className="value">{shipperData.Email || "Chưa cập nhật"}</span>
        </div>
      </div>
    </div>
  );

  const renderVehicleInfo = () => (
    <div className="section-content">
      <h2>Thông tin phương tiện</h2>
      <div className="info-grid">
        <div className="info-item">
          <span className="label">Loại xe:</span>
          <span className="value">{shipperData.VehicleType || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Biển số xe:</span>
          <span className="value">{shipperData.LicensePlate || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Số GPLX:</span>
          <span className="value">{shipperData.LicenseNumber || "Chưa cập nhật"}</span>
        </div>
      </div>
    </div>
  );

  const renderAddressInfo = () => (
    <div className="section-content">
      <h2>Địa chỉ</h2>
      <div className="info-grid">
        <div className="info-item">
          <span className="label">Địa chỉ:</span>
          <span className="value">{shipperData.FullAddress || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Phường/Xã:</span>
          <span className="value">{shipperData.Ward || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Quận/Huyện:</span>
          <span className="value">{shipperData.District || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Tỉnh/Thành phố:</span>
          <span className="value">{shipperData.City || "Chưa cập nhật"}</span>
        </div>
      </div>
    </div>
  );

  const renderBankInfo = () => (
    <div className="section-content">
      <h2>Thông tin ngân hàng</h2>
      <div className="info-grid">
        <div className="info-item">
          <span className="label">Tên ngân hàng:</span>
          <span className="value">{shipperData.BankName || "Chưa cập nhật"}</span>
        </div>
        <div className="info-item">
          <span className="label">Số tài khoản:</span>
          <span className="value">{shipperData.BankAccountNumber || "Chưa cập nhật"}</span>
        </div>
      </div>
    </div>
  );

  const renderDocuments = () => (
    <div className="section-content">
      <h2>Giấy tờ</h2>
      <div className="documents-grid">
        {shipperData.DriverLicenseImage && (
          <div className="document-item">
            <h3>Giấy phép lái xe</h3>
            <img 
              src={shipperData.DriverLicenseImage} 
              alt="Giấy phép lái xe" 
              className="document-image" 
            />
          </div>
        )}
        {shipperData.VehicleRegistrationImage && (
          <div className="document-item">
            <h3>Đăng ký xe</h3>
            <img 
              src={shipperData.VehicleRegistrationImage} 
              alt="Đăng ký xe" 
              className="document-image" 
            />
          </div>
        )}
      </div>
    </div>
  );

  // Render content based on selected section
  const renderSelectedSectionContent = () => {
    switch (selectedSection) {
      case 'personal-info':
        return renderPersonalInfo();
      case 'vehicle-info':
        return renderVehicleInfo();
      case 'address-info':
        return renderAddressInfo();
      case 'bank-info':
        return renderBankInfo();
      case 'documents':
        return renderDocuments();
      default:
        return renderPersonalInfo();
    }
  };


  // Loading state
  if (loading) return (
    <div className="shipper-container">
      <Header />
      <div className="loading-container">
        <div className="loading">
          <div className="loading-spinner"></div>
          <p>Đang tải thông tin...</p>
        </div>
      </div>
      <Footer />
    </div>
  );
  // Error state
  if (error) return (
    <div className="shipper-container">
      <Header />
      <div className="error-container">
        <div className="error">
          <p>Lỗi: {error}</p>
          <button onClick={() => window.location.reload()}>Tải lại</button>
        </div>
      </div>
      <Footer />
    </div>
  );
  return (
    <div className="shipper-container">
      <Header />
      <main className="shipper-main">
        <div className="shipper-account-layout">
          <div className="left-sidebar">
            <div 
              className={`sidebar-item ${selectedSection === 'personal-info' ? 'active' : ''}`}
              onClick={() => setSelectedSection('personal-info')}
            >
              Thông tin cá nhân
            </div>
            <div 
              className={`sidebar-item ${selectedSection === 'vehicle-info' ? 'active' : ''}`}
              onClick={() => setSelectedSection('vehicle-info')}
            >
              Thông tin phương tiện
            </div>
            <div 
              className={`sidebar-item ${selectedSection === 'address-info' ? 'active' : ''}`}
              onClick={() => setSelectedSection('address-info')}
            >
              Địa chỉ
            </div>
            <div 
              className={`sidebar-item ${selectedSection === 'bank-info' ? 'active' : ''}`}
              onClick={() => setSelectedSection('bank-info')}
            >
              Thông tin ngân hàng
            </div>
            <div 
              className={`sidebar-item ${selectedSection === 'documents' ? 'active' : ''}`}
              onClick={() => setSelectedSection('documents')}
            >
              Giấy tờ
            </div>
          </div>
          <div className="right-content">
            {renderSelectedSectionContent()}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ShipperAccount;