import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../../../styles/ReportIssue.css";
import axios from "axios";
import { Header } from "../../header/Header";
import Footer from "../../footer/Footer";

const ReportIssue = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [shipperId, setShipperId] = useState(null);
  const [reportType, setReportType] = useState(""); 
  const location = useLocation();
  const navigate = useNavigate();

  const [report, setReport] = useState({
    orderId: "",
    incidentCategory: "",
    description: "",
  });

  // Lấy shipperId từ localStorage khi component mount
  useEffect(() => {
    const storedShipperId = localStorage.getItem('shipperId');
    if (storedShipperId) {
      setShipperId(storedShipperId);
    }
  }, []);

  // Kiểm tra và điền OrderID từ state navigate
  useEffect(() => {
    // Kiểm tra xem có OrderID được truyền từ trang OrderDetails không
    if (location.state && location.state.orderId) {
      setReport(prevReport => ({
        ...prevReport,
        orderId: location.state.orderId
      }));
      setReportType("order"); // Tự động chọn báo cáo đơn hàng
    }
  }, [location.state]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setReport({ ...report, [name]: value });
  };

  const handleReportTypeChange = (e) => {
    setReportType(e.target.value);
    setReport({ orderId: "", incidentCategory: "", description: "" }); 
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (reportType === "order") {
        const response = await axios.post("http://localhost:5000/api/reports/order", { 
          ...report, 
          shipperId 
        });
        if (response.data.success) {
          setIsSubmitted(true);
          setTimeout(() => {
            setIsSubmitted(false);
            navigate('/dashboard'); // Chuyển về dashboard sau khi gửi báo cáo thành công
          }, 3000);
        }
      } else if (reportType === "shipper") {
        if (!shipperId) {
          console.error("Không thể gửi báo cáo do thiếu shipperId");
          return;
        }
        const response = await axios.post("http://localhost:5000/api/reports/shipper", { 
          ...report, 
          shipperId 
        });
        if (response.data.success) {
          setIsSubmitted(true);
          setTimeout(() => {
            setIsSubmitted(false);
            navigate('/dashboard');
          }, 3000);
        }
      }
    } catch (error) {
      console.error("Lỗi gửi báo cáo:", error);
    }
  };

  return (
    <div className="report-issue-page">
      <div className="report-issue-header">
        <Header />
      </div>
      <div className="report-issue-container-wrapper">
        <div className="report-issue-container">
          <h2>Báo cáo Sự cố</h2>
          <p><strong>ID Shipper:</strong> {shipperId || "Không có ID"}</p>
          {isSubmitted && <p className="report-issue-success-msg">Báo cáo đã được gửi!</p>}

          {!reportType ? (
            <div className="report-issue-type-selection">
              <label>Chọn loại báo cáo:</label>
              <select value={reportType} onChange={handleReportTypeChange} required>
                <option value="">Chọn loại báo cáo</option>
                <option value="order">Báo cáo sự cố đơn hàng</option>
                <option value="shipper">Shipper báo cáo sự cố với Admin</option>
              </select>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="report-issue-form">
              {reportType === "order" && (
                <>
                  <label>Mã đơn hàng:</label>
                  <input
                    type="text"
                    name="orderId"
                    value={report.orderId}
                    onChange={handleChange}
                    required
                    placeholder="Nhập mã đơn hàng"
                    // Nếu đã có OrderID từ OrderDetails thì không cho sửa
                    readOnly={location.state && location.state.orderId}
                  />
                </>
              )}

              {/* Phần còn lại giữ nguyên */}
              <label>Danh mục sự cố:</label>
              <select
                name="incidentCategory"
                value={report.incidentCategory}
                onChange={handleChange}
                required
              >
                <option value="">Chọn danh mục</option>
                {reportType === "order" ? (
                  <>
                    <option value="Vấn đề về địa chỉ">Vấn đề về địa chỉ</option>
                    <option value="Sai sản phẩm">Sai sản phẩm</option>
                    <option value="Giao hàng trễ">Giao hàng trễ</option>
                    <option value="Hư hỏng sản phẩm">Hư hỏng sản phẩm</option>
                    <option value="Khác">Khác</option>
                  </>
                ) : (
                  <>
                    <option value="Hỏng phương tiện">Hỏng phương tiện</option>
                    <option value="Tai nạn giao thông">Tai nạn giao thông</option>
                    <option value="Mất tài sản">Mất tài sản</option>
                    <option value="Tai nạn do đối tác">Tai nạn do đối tác</option>
                    <option value="Khác">Khác</option>
                  </>
                )}
              </select>

              <label>Mô tả chi tiết:</label>
              <textarea
                name="description"
                value={report.description}
                onChange={handleChange}
                required
                placeholder="Mô tả sự cố..."
              ></textarea>

              <button type="submit" className="report-issue-submit-btn">Gửi báo cáo</button>
              <button
                type="button"
                className="report-issue-back-btn"
                onClick={() => setReportType("")}
              >
                Quay lại
              </button>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ReportIssue;